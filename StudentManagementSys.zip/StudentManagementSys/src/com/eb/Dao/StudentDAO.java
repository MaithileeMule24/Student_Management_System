package com.eb.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.eb.Db.Dbconnect;
import com.eb.pojo.Student;

public class StudentDAO {
	public static boolean insertRecord(Student s) {

		boolean b = false;

		try {
			Connection connect = Dbconnect.create();

			String query = "insert into student(studentName, studentPhone, studentCity) values(?,?,?)";

			PreparedStatement prepare = connect.prepareStatement(query);

			prepare.setString(1, s.getStudentName());
			prepare.setString(2, s.getStudentPhone());
			prepare.setString(3, s.getStudentCity());

			prepare.executeUpdate();

			b = true;
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	public static void showAll() {

		boolean b = false;

		try {
			Connection connect = Dbconnect.create();
			String query = "select * from students";
			Statement state = connect.createStatement();
			ResultSet result = state.executeQuery(query);

			while (result.next()) {

				String name = result.getString(2);
				String phone = result.getString(3);
				String city = result.getString(4);

				System.out.println("Student Name: " + name);
				System.out.println("Student Phone: " + phone);
				System.out.println("Student City: " + city);
				System.out.println("----------------------------------------------");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static boolean updateRecord(int value, String update, int id, Student std) {

		boolean b = false;

		try {
			Connection connect = Dbconnect.create();

			// UPDATE NAME
			if (value == 1) {

				String query = "update students set name=? where id=?";
				PreparedStatement prepare = connect.prepareStatement(query);
				prepare.setString(1, update);
				prepare.setInt(2, id);

				// EXECUTE
				prepare.executeUpdate();
				b = true;
			}

			// UPDATE PHONE
			else if (value == 2) {
				String query = "update students set phoneno=? where id=?";
				PreparedStatement prepare = connect.prepareStatement(query);
				prepare.setString(1, update);
				prepare.setInt(2, id);

				// EXECUTE
				prepare.executeUpdate();
				b = true;
			}

			// UPDATE CITY
			else if (value == 3) {
				String query = "update students set city=? where id=?";
				PreparedStatement prepare = connect.prepareStatement(query);
				prepare.setString(1, update);
				prepare.setInt(2, id);

				// EXECUTE
				prepare.executeUpdate();
				b = true;
			}

			else {

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return b;
	}

	public static boolean deleteRecord(int userId) {

		boolean b = false;

		try {
			Connection connect = Dbconnect.create();
			String query = "delete from students where id=?";
			PreparedStatement prepare = connect.prepareStatement(query);
			// SET THE VALUE OF PARAMETERS
			prepare.setInt(1, userId);

			// EXECUTE
			prepare.executeUpdate();

			b = true;
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return b;
	}
}
