package com.eb.Db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Dbconnect {
	static Connection connect;

	public static Connection create() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/oct22";
			String username = "root";
			String password = "root";

			connect = DriverManager.getConnection(url, username, password);
		}

		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return connect;

	}
}
