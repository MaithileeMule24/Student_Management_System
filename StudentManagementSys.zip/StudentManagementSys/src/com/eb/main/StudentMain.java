package com.eb.main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import com.eb.Dao.StudentDAO;
import com.eb.pojo.Student;

public class StudentMain {
	public static void main(String[] args) throws Exception {

	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	System.out.println("Hello User! Please enter your name: \n");
	String user = br.readLine();
	System.out.println("Welcome to student management app! " + user);

    while(true)
	{
		System.out.println("Press 1 to add student");
		System.out.println("Press 2 to delete student");
		System.out.println("Press 3 to display student");
		System.out.println("Press 4 to update student");
		System.out.println("Press 5 to exit app");

		int c = Integer.parseInt(br.readLine());

		// ADD STUDENT

		if (c == 1) {

			System.out.println("Enter student name: ");
			String name = br.readLine();
			System.out.println("Enter student phone: ");
			String phone = br.readLine();
			System.out.println("Enter student city: ");
			String city = br.readLine();

			// CREATE STUDENT OBJECT

			Student st = new Student(name, phone, city);
			boolean ans = StudentDAO.insertRecord(st);
			if (ans) {
				System.out.println("Student record inserted successfully!");
				System.out.println("Student Record:" + st);
			} else {
				System.out.println("Some error Occured While Inserting...Please try Again!");
			}
		}

		// DELETE STUDENT

		else if (c == 2) {
			System.out.println("Enter Student ID To Delete: ");
			int userId = Integer.parseInt(br.readLine());
			boolean f = StudentDAO.deleteRecord(userId);
			if (f) {
				System.out.println("Student Of ID " + userId + " Record Deleted... ");
			} else {
				System.out.println("Something Went Wrong.. Please try Again!");
			}
		}

		// DISPLAY STUDENT

		else if (c == 3) {
			StudentDAO.showAll();
		}

		// UPDATE STUDENT

		else if (c == 4) {
			System.out.println("PRESS 1 to UPDATE name");
			System.out.println("PRESS 2 to UPDATE phone");
			System.out.println("PRESS 3 to UPDATE city");
			int val = Integer.parseInt(br.readLine());
			if (val == 1) {
				// Update Name
				System.out.println("Enter name to UPDATE...");
				String name = br.readLine();
				System.out.println("Enter ID to identify student!");
				int id = Integer.parseInt(br.readLine());
				Student st = new Student();
				st.setStudentName(name);
				boolean f = StudentDAO.updateRecord(val, name, id, st);
				if (f) {
					System.out.println("Student Name Updated Successfully...");
				} else {
					System.out.println("Something Went Wrong Please try Again!");
				}
			}

			else if (val == 2) {
				// Update Phone
				System.out.println("Enter phone to UPDATE...");
				String phone = br.readLine();
				System.out.println("Enter ID to identify student!");
				int id = Integer.parseInt(br.readLine());
				Student st = new Student();
				st.setStudentPhone(phone);
				boolean f = StudentDAO.updateRecord(val, phone, id, st);
				if (f) {
					System.out.println("Student Phone Updated Successfully...");
				} else {
					System.out.println("Something Went Wrong Please try Again!");
				}
			}

			else if (val == 3) {
				// Update city
				System.out.println("Enter city to UPDATE...");
				String city = br.readLine();
				System.out.println("Enter ID to identify student!");
				int id = Integer.parseInt(br.readLine());
				Student st = new Student();
				st.setStudentCity(city);
				boolean f = StudentDAO.updateRecord(val, city, id, st);
				if (f) {
					System.out.println("Student City Updated Successfully...");
				}

				else {
					System.out.println("Something Went Wrong Please try Again!");
				}
			}

			else {
				System.out.println("Hey You have not updated Anything... Please choose option Correctly!");
			}

			// EXIT

		} else if (c == 5) {

			System.out.println("Thank you for using application " + user);
			break;
		} else {

		}
	}
}
}

